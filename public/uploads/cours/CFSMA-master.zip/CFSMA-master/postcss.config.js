module.exports = {
    plugins: {
        autoprefixer: {}
    }
}